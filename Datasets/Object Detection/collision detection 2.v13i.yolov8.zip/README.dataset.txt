# collision detection 2 > 2024-07-09 5:28pm
https://universe.roboflow.com/designproject-e9sz7/collision-detection-2

Provided by a Roboflow user
License: CC BY 4.0

