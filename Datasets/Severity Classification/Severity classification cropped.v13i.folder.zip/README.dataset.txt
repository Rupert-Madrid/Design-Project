# Severity classification cropped > 2024-07-10 4:27am
https://universe.roboflow.com/designproject-e9sz7/severity-classification-cropped

Provided by a Roboflow user
License: CC BY 4.0

